
class InvalidSection(Exception):
    pass
