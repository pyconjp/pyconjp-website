VERSION = (0, 10, 0, 'alpha', 1)
