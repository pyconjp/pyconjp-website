"""Reversion management utilities."""

from __future__ import unicode_literals