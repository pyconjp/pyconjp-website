# XXX these were copied as a quick fix; need to address this soon
class TAB:
    pass

# XXX these were copied as a quick fix; need to address this soon
class LINE:
    pass

class RawCode:
    def __init__(self, data):
        self.Data = data
