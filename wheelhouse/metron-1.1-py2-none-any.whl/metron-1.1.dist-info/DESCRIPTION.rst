======
Metron
======


Current analytics services supported:

* Google Analytics
* Mixpanel
* gaug.es
* Google AdWords Conversion Tracking


Documentation
-------------

Documentation can be found online at http://metron.readthedocs.org/


