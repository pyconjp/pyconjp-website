from constance.config import Config

config = Config()
